import java.io.*;
import java.net.*;

public class Client {

    private Socket socket;
    private BufferedReader br;
    private PrintWriter out;
    private volatile boolean running = true;

    public Client() {
        try {
            socket = new Socket("127.0.0.1", 6666);
            System.out.println("Connected to server.");

            br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            Reading();
            Writing();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

public void Reading() {
    Runnable r1 = () -> {
        try {
            System.out.println("Reading is performing ");
            String line;
            while (running && (line = br.readLine()) != null) {
                System.out.println("Server: " + line);
            }
            System.out.println("Socket Closed");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                br.close(); // Close BufferedReader
                socket.close(); // Close Socket
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    };

    Thread read_t1 = new Thread(r1);
    read_t1.start();
}

    public void Writing() {
        System.out.println("Writing is performing ");

        Runnable r2 = () -> {
            try {
                BufferedReader b1 = new BufferedReader(new InputStreamReader(System.in));
                String content;
                while (running && !(content = b1.readLine()).equalsIgnoreCase("exit")) {
                    out.println(content);
                    out.flush();
                }
                out.close(); // Close PrintWriter
                socket.close(); // Close Socket
                System.out.println("Socket Closed");
                running = false; // Set running flag to false when exit command is entered
            } catch (Exception e) {
                e.printStackTrace();
            }
        };

        Thread writerThread = new Thread(r2);
        writerThread.start();
    }

    public static void main(String[] args) {
        System.out.println("Client is running");
        new Client();
    }
}
