import mypack.Start;
public class Test 
{
    public static void main(String args[])
    {
        //1st method 
        mypack.Start ob = new mypack.Start();
        ob.display();

        //2nd Method 
        Start ob1 = new Start();
        ob1.display();

        // 3rd Method 
        // import mypack.*;
        Start ob2 = new Start();
        ob2.display();

    }
}