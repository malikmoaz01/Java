package mypack;
public class Start 
{
	public void display()
	{
		System.out.println("Start Display Function");
	}
	public static void main(String args[])
	{
		System.out.println("Start Class Main");
	}
}