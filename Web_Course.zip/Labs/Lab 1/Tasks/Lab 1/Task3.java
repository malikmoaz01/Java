public class Task3 {
    public static void main(String args[]){
        double payAmount = 2000.0;
        double payPeriods = 12;
        double annualPay = payAmount * payPeriods;
        System.out.println("The Total Annual Pay is " + annualPay );
    }
}